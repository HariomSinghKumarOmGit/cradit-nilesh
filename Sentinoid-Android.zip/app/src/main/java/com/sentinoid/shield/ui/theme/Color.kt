package com.sentinoid.shield.ui.theme

import androidx.compose.ui.graphics.Color

val Purple80 = Color(0xFFD0BCFF)
val PurpleGrey80 = Color(0xFFCCC2DC)
val Pink80 = Color(0xFFEFB8C8)

val Purple40 = Color(0xFF6650a4)
val PurpleGrey40 = Color(0xFF625b71)
val Pink40 = Color(0xFF7D5260)

val SentinelBlue = Color(0xFF1A73E8)
val SentinelDark = Color(0xFF0D47A1)
val SentinelGreen = Color(0xFF34A853)
