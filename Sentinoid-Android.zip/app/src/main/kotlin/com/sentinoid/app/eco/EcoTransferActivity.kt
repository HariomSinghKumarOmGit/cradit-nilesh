package com.sentinoid.app.eco

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.text.InputType
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import com.google.android.material.card.MaterialCardView
import com.sentinoid.app.R

/**
 * ECO Secure File Transfer Activity
 *
 * Provides two transfer modes:
 * 1. LAN Transfer — Opens ECO running on a local network server in the device browser.
 *    Maintains Sentinoid's air-gap policy (no INTERNET permission needed in this app).
 * 2. Internet Transfer — Opens a hosted ECO instance URL in the device browser.
 *    The URL can be updated once ECO is deployed to a public server.
 */
class EcoTransferActivity : AppCompatActivity() {

    companion object {
        // Default LAN server address (user can customize)
        private const val DEFAULT_LAN_HOST = "192.168.1.100"
        private const val DEFAULT_LAN_PORT = "3000"

        // Placeholder URL for the hosted ECO instance
        // Update this once ECO is deployed to a public server
        private const val ECO_HOSTED_URL = "https://eco-transfer.example.com"
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_eco_transfer)

        setupUI()
    }

    private fun setupUI() {
        // Back button
        findViewById<ImageView>(R.id.btn_back).setOnClickListener {
            finish()
        }

        // LAN Transfer Card
        findViewById<MaterialCardView>(R.id.card_lan_transfer).setOnClickListener {
            showLanConnectionDialog()
        }

        // Internet Transfer Card
        findViewById<MaterialCardView>(R.id.card_internet_transfer).setOnClickListener {
            openInternetTransfer()
        }
    }

    /**
     * Shows a dialog where the user can enter the LAN server address
     * (IP and port of the machine running ECO's signaling server).
     * Then opens the address in the device's browser.
     */
    private fun showLanConnectionDialog() {
        val dialogView = layoutInflater.inflate(R.layout.dialog_lan_address, null)
            ?: run {
                // Fallback if layout is not available — use programmatic EditText
                showSimpleLanDialog()
                return
            }

        val inputHost = dialogView.findViewById<EditText>(R.id.input_host)
        val inputPort = dialogView.findViewById<EditText>(R.id.input_port)

        inputHost.setText(DEFAULT_LAN_HOST)
        inputPort.setText(DEFAULT_LAN_PORT)

        AlertDialog.Builder(this)
            .setTitle(getString(R.string.eco_lan_dialog_title))
            .setMessage(getString(R.string.eco_lan_dialog_message))
            .setView(dialogView)
            .setPositiveButton(getString(R.string.eco_lan_dialog_connect)) { _, _ ->
                val host = inputHost.text.toString().trim()
                val port = inputPort.text.toString().trim()

                if (host.isNotEmpty()) {
                    val url = if (port.isNotEmpty()) "http://$host:$port" else "http://$host"
                    openInBrowser(url)
                } else {
                    Toast.makeText(this, getString(R.string.eco_lan_invalid_address), Toast.LENGTH_SHORT).show()
                }
            }
            .setNegativeButton(getString(R.string.dialog_cancel), null)
            .show()
    }

    /**
     * Simple fallback LAN dialog using programmatic EditText
     */
    private fun showSimpleLanDialog() {
        val input = EditText(this).apply {
            inputType = InputType.TYPE_CLASS_TEXT
            hint = "e.g. 192.168.1.100:3000"
            setText("$DEFAULT_LAN_HOST:$DEFAULT_LAN_PORT")
            setPadding(48, 32, 48, 32)
        }

        val container = FrameLayout(this).apply {
            setPadding(32, 0, 32, 0)
            addView(input)
        }

        AlertDialog.Builder(this)
            .setTitle(getString(R.string.eco_lan_dialog_title))
            .setMessage(getString(R.string.eco_lan_dialog_message))
            .setView(container)
            .setPositiveButton(getString(R.string.eco_lan_dialog_connect)) { _, _ ->
                val address = input.text.toString().trim()
                if (address.isNotEmpty()) {
                    val url = if (address.startsWith("http")) address else "http://$address"
                    openInBrowser(url)
                } else {
                    Toast.makeText(this, getString(R.string.eco_lan_invalid_address), Toast.LENGTH_SHORT).show()
                }
            }
            .setNegativeButton(getString(R.string.dialog_cancel), null)
            .show()
    }

    /**
     * Opens the hosted ECO instance in the device's browser.
     */
    private fun openInternetTransfer() {
        if (ECO_HOSTED_URL.contains("example.com")) {
            // URL not yet configured — show info dialog
            AlertDialog.Builder(this)
                .setTitle(getString(R.string.eco_internet_not_ready_title))
                .setMessage(getString(R.string.eco_internet_not_ready_message))
                .setPositiveButton(getString(R.string.dialog_ok), null)
                .show()
        } else {
            openInBrowser(ECO_HOSTED_URL)
        }
    }

    /**
     * Opens a URL in the device's default browser using an Intent.
     * This does NOT require INTERNET permission in our app manifest —
     * the browser app handles the network access.
     */
    private fun openInBrowser(url: String) {
        try {
            val intent = Intent(Intent.ACTION_VIEW, Uri.parse(url))
            startActivity(intent)
        } catch (e: Exception) {
            Toast.makeText(
                this,
                getString(R.string.eco_browser_error),
                Toast.LENGTH_LONG
            ).show()
        }
    }
}
